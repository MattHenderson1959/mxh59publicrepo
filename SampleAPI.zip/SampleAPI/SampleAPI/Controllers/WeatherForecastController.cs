﻿using Messages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NServiceBus;
using SampleAPI.DAL;
using SampleAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace SampleAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;        
        private readonly IConfigurationRoot configuration = new ConfigurationBuilder()
            //.SetBasePath([PATH_WHERE_appsettings.json_RESIDES])
            .AddJsonFile("appsettings.json")
            .Build();

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            })
            .ToArray();
        }

        [HttpGet("{city}")]
        public async Task<ActionResult<string>> Get(string city)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders
                .Accept
                .Add(new MediaTypeWithQualityHeaderValue("application/json"));

            StringBuilder sb = new StringBuilder();
            sb.Append("https://api.weatherapi.com/v1/current.json?key=");
            sb.Append(Environment.GetEnvironmentVariable("WEATHERAPI_KEY", EnvironmentVariableTarget.Machine));
            sb.Append("&q=");
            sb.Append(city);
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, sb.ToString());

            string response = string.Empty;
            try
            {
                HttpResponseMessage result = await client.SendAsync(request);
                result.EnsureSuccessStatusCode();
                response = await result.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                _logger.LogDebug(string.Format("Error!  Message = {0}", ex.Message));
            }

            return response;

        }

        [HttpPost("{phone}")]
        public ActionResult<string> PostSMS(string phone)
        {
            // Find your Account SID and Auth Token at twilio.com/console
            // and set the environment variables. See http://twil.io/secure
            string accountSid = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID", EnvironmentVariableTarget.Machine);
            string authToken = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN", EnvironmentVariableTarget.Machine);

            TwilioClient.Init(accountSid, authToken);

            StringBuilder sb = new StringBuilder();
            sb.Append("+1");
            sb.Append(phone);

            var message = MessageResource.Create(
                body: "Join Earth's mightiest heroes. Like Kevin Bacon.",
                from: new Twilio.Types.PhoneNumber("+16514017793"),
                to: new Twilio.Types.PhoneNumber(sb.ToString())
            );

            return message.Sid;
        }

        [HttpPost]
        [Route("{phone}/{message}")]
        public async Task<ActionResult<ApiRequestItem>> PostSMSDB(string phone, string message)
        {
            var endpointConfiguration = new EndpointConfiguration("ClientUI");
            _ = endpointConfiguration.UseTransport<LearningTransport>();

            var endpointInstance = await Endpoint.Start(endpointConfiguration)
                .ConfigureAwait(false);

            ApiRequestItem ari = new ApiRequestItem
            {
                PhoneNumber = phone,
                Message = message
            };

            SampleDAL sDAL = new SampleDAL(configuration);
            ari = sDAL.WriteRequest(ari);

            if (ari.Id > 0)
            {
                var command = new SendSMS
                {
                    Id = ari.Id,
                    Message = ari.Message,
                    PhoneNumber = ari.PhoneNumber
                };

                // Send the command to the local endpoint
                _logger.LogDebug($"Sending SendSMS command, Id = {command.Id}");
                await endpointInstance.SendLocal(command)
                    .ConfigureAwait(false);
            }
            
            return ari;
        }
    } 
}
