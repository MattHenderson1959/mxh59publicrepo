using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using SampleAPI.Controllers;
using SampleAPI.Models;

namespace NUnitTests
{
    public class Tests
    {
        private readonly ILogger<WeatherForecastController> logger;
        private readonly IConfigurationRoot configuration = new ConfigurationBuilder()
    //.SetBasePath([PATH_WHERE_appsettings.json_RESIDES])
    .AddJsonFile("appsettings.json")
    .Build();

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public async void GetWorcesterWeather()
        {
            var controller = new WeatherForecastController(logger);
            var result = await controller.Get("Worcester");
            Assert.IsNotNull(result);
        }

        [Test]
        public void TestSampleDAL()
        {
            var dal = new SampleAPI.DAL.SampleDAL(configuration);
            ApiRequestItem ari = new ApiRequestItem
            {
                Message = "NUnit testing of DAL",
                PhoneNumber = "5088081485"
            };

            var result = dal.WriteRequestORM(ari);
            Assert.Greater(result.Id, 0);
        }
    }
}