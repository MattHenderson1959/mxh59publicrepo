﻿using SampleAPI.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SampleAPI.DAL
{
    public class SampleDAL
    {
        private readonly string _connectionString;

        public SampleDAL()
        {
        }
        public SampleDAL(IConfiguration iconfiguration)
        {
            _connectionString = iconfiguration.GetSection("ConnectionStrings").GetSection("DefaultConnection").Value;
        }
        public ApiRequestItem WriteRequest(ApiRequestItem ari)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("INSERT INTO APIRequest VALUES(@message, @phone) ");
                sb.Append("SELECT CAST(SCOPE_IDENTITY() AS int)");
                
                using SqlConnection con = new SqlConnection(_connectionString);
                SqlCommand cmd = new SqlCommand("SP_Sample_GET_LIST", con)
                {
                    CommandType = CommandType.Text,
                    CommandText = sb.ToString()
                };

                cmd.Parameters.AddWithValue("@message", ari.Message);
                cmd.Parameters.AddWithValue("@phone", ari.PhoneNumber);

                con.Open();

                ari.Id = (int)cmd.ExecuteScalar();

                if (con.State.Equals("Open"))
                {
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ari;
        }
    }
}