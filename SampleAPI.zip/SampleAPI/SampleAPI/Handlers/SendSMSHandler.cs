﻿using Messages;
using NServiceBus;
using NServiceBus.Logging;
using System;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace SampleAPI.Handlers
{
    public class SendSMSHandler : IHandleMessages<SendSMS>
    {
        static readonly ILog log = LogManager.GetLogger<SendSMSHandler>();

        public Task Handle(SendSMS message, IMessageHandlerContext context)
        {
            log.Info($"Received SendSMS, Id = {message.Id}");

            string accountSid = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID", EnvironmentVariableTarget.Machine);
            string authToken = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN", EnvironmentVariableTarget.Machine);

            TwilioClient.Init(accountSid, authToken);

            StringBuilder sb = new StringBuilder();
            sb.Append("+1");
            sb.Append(message.PhoneNumber);
            _ = MessageResource.Create(
                body: message.Message,
                from: new Twilio.Types.PhoneNumber("+16514017793"),
                to: new Twilio.Types.PhoneNumber(sb.ToString())
            );

            return Task.CompletedTask;
        }

    }
}
