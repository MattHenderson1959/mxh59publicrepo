﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Messages
{
    public class SendSMS : NServiceBus.ICommand
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public string PhoneNumber { get; set; }
    }
}
